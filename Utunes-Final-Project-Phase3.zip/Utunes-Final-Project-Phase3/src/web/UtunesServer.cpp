#include "UtunesServer.hpp"

UtunesServer::UtunesServer(int port) : Server(port) {}
