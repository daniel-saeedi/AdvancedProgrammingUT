#ifndef XOR_ENCRYPTION_H
#define XOR_ENCRYPTION_H
#include <iostream>
#include <string>
class XOREncryption
{
public:
	static std::string encrypt_decrypt(std::string text);
};
#endif